package com.example.hrms.biz.user.controller;

import com.example.hrms.biz.booking.model.Booking;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/users")
public class UserController {

    @RequestMapping("")
    public String openUserView(Model model, HttpSession session) {
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/users/login"; // Chuyển hướng đến trang đăng nhập nếu session hết hạn
        }
        model.addAttribute("user", new Booking());
        return "user";
    }

    @RequestMapping("/login")
    public String loginPage() {
        return "login"; // Trả về trang login.html
    }

    @RequestMapping("/create")
    public String createAccountPage() {
        return "createaccount"; // Trả về trang create-account.html
    }

    @RequestMapping("/home")
    public String homePage(Model model, HttpSession session) {
        if (session == null || session.getAttribute("user") == null) {
            return "redirect:/users/login"; // Chuyển hướng đến trang đăng nhập nếu session hết hạn
        }
        return "index";
    }
}